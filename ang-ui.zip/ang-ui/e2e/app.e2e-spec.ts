import { AngUiPage } from './app.po';

describe('ang-ui App', () => {
  let page: AngUiPage;

  beforeEach(() => {
    page = new AngUiPage();
  });

  it('should display welcome message', () => {
    page.navigateTo();
    expect(page.getParagraphText()).toEqual('Welcome to app!!');
  });
});
