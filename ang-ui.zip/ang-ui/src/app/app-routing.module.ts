import { NgModule }             from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { AngDataComponent }  from './angdata/angdata.component';

const routes: Routes = [
  { path: '', redirectTo: '/angdata', pathMatch: 'full' },
  { path: 'angdata',  component: AngDataComponent }
];

@NgModule({
  imports: [ RouterModule.forRoot(routes) ],
  exports: [ RouterModule ]
})
export class AppRoutingModule {}
