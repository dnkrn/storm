import { AngData } from './AngData'

export const ANGDATAPROFILES: AngData[] = [
  { id: 11, profileName: 'WindStorm', clientType: 'internal' ,ach :true},
  { id: 12, profileName: 'StormRain', clientType: 'external' ,ach :false},
  { id: 13, profileName: 'RainForest', clientType: 'internal' ,ach :true},
  { id: 14, profileName: 'ForestRiver', clientType: 'external' ,ach :false},
  { id: 15, profileName: 'RiverWater', clientType: 'internal' ,ach :true}];
