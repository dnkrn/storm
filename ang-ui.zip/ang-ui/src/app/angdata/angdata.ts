export class AngData {
  id: number;
  profileName: string;
  clientType: string;
  ach:boolean;
}
