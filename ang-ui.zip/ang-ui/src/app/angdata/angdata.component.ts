import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ANGDATAPROFILES } from './mock-angdata';

import { AngData } from './angdata';
import { AngDataService } from './angdata.service';


@Component({
  selector: 'ang-data',
  templateUrl: './angdata.component.html',
  styleUrls: ['./angdata.component.css'],
  providers: [AngDataService]
})

export class AngDataComponent {
  title = 'ANG DCT';
  selectedProfile: AngData;
  profiles: AngData[];

  selectedAch=false;

  onSelect(profile: AngData): void {
    this.selectedProfile = profile;
      this.selectedAch = this.selectedProfile.ach;
  }

  onSelectAch(attr):void{
      this.selectedAch = this.selectedProfile.ach;
  }


  constructor(private angDataService: AngDataService) { }

  getProfiles(): void {
    this.angDataService.getProfiles().then(profiles => this.profiles = profiles);

  }

  ngOnInit(): void {
    this.getProfiles();

  }

}
