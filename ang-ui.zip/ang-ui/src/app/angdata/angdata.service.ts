
import { Injectable } from '@angular/core';

import { AngData } from './angdata';
import { ANGDATAPROFILES } from './mock-angdata';

@Injectable()
export class AngDataService {
  getProfiles(): Promise<AngData[]> {
    return Promise.resolve(ANGDATAPROFILES);
  }
}
